# Program to count the occurrence of the word "INDIA" in a text file India.txt

def count_occurrences(filename, word):
    with open(filename, 'r') as file:
        text = file.read()
    return text.upper().count(word.upper())

filename = 'India.txt'
word = 'INDIA'
print(f"The word '{word}' occurs {count_occurrences(filename, word)} times in the file {filename}.")
