# Program to count the number of vowels and consonants in a file Myfile.txt

def count_vowels_and_consonants(filename):
    vowels = 'AEIOUaeiou'
    vowel_count = 0
    consonant_count = 0

    with open(filename, 'r') as file:
        text = file.read()
    
    for char in text:
        if char.isalpha():
            if char in vowels:
                vowel_count += 1
            else:
                consonant_count += 1

    return vowel_count, consonant_count

filename = 'Myfile.txt'
vowel_count, consonant_count = count_vowels_and_consonants(filename)
print(f"Number of vowels: {vowel_count}")
print(f"Number of consonants: {consonant_count}")
