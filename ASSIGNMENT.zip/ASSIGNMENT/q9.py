# Program to display the lines having more than five words in a text file Notes.txt

def display_lines_with_more_than_five_words(filename):
    with open(filename, 'r') as file:
        lines = file.readlines()

    for line in lines:
        if len(line.split()) > 5:
            print(line.strip())

filename = 'Notes.txt'
display_lines_with_more_than_five_words(filename)
