# Program to calculate simple interest using a function
def calculate_simple_interest(principal, rate, time):
    return (principal * rate * time) / 100

principal = float(input("Enter the principal amount: "))
rate = float(input("Enter the rate of interest: "))
time = float(input("Enter the time in years: "))
print(f"The simple interest is {calculate_simple_interest(principal, rate, time)}.")
