# Program to count and display the number of words starting with "I" in a file Word.txt

def count_words_starting_with_i(filename):
    with open(filename, 'r') as file:
        text = file.read()
    
    words = text.split()
    count = sum(1 for word in words if word.startswith('I') or word.startswith('i'))

    return count

filename = 'Word.txt'
print(f"Number of words starting with 'I': {count_words_starting_with_i(filename)}")
