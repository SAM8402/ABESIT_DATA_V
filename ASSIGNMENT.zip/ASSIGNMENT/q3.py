# Program to print the sum of two numbers using a function
def sum_of_two_numbers(a, b):
    return a + b

a = int(input("Enter the first number: "))
b = int(input("Enter the second number: "))
print(f"The sum of {a} and {b} is {sum_of_two_numbers(a, b)}.")
