# Program to create a binary file Stu.dat and enter student roll number, name, and marks till the user wants/

import pickle

def create_student_file(filename):
    with open(filename, 'wb') as file:
        while True:
            roll_no = input("Enter roll number: ")
            name = input("Enter name: ")
            marks = float(input("Enter marks: "))

            student = {'roll_no': roll_no, 'name': name, 'marks': marks}
            pickle.dump(student, file)

            cont = input("Do you want to add another record? (yes/no): ")
            if cont.lower() != 'yes':
                break

filename = 'Stu.dat'
create_student_file(filename)
