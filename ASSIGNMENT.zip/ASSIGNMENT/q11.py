# Program to read a binary file Stu.dat and display the record of students having marks greater than 81

import pickle

def display_high_scoring_students(filename, threshold):
    with open(filename, 'rb') as file:
        try:
            while True:
                student = pickle.load(file)
                if student['marks'] > threshold:
                    print(student)
        except EOFError:
            pass

filename = 'Stu.dat'
threshold = 81
display_high_scoring_students(filename, threshold)
