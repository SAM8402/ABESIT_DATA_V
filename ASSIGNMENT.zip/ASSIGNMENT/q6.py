# Program to count and display the lines starting with "T" in a text file story.txt

def count_lines_starting_with_t(filename):
    with open(filename, 'r') as file:
        lines = file.readlines()
    
    count = 0
    for line in lines:
        if line.strip().startswith('T'):
            print(line.strip())
            count += 1

    return count

filename = 'story.txt'
print(f"Number of lines starting with 'T': {count_lines_starting_with_t(filename)}")
