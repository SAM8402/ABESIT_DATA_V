#  Function to count uppercase characters in a text file ABC.txt
def count_uppercase_characters(filename):
    with open(filename, 'r') as file:
        text = file.read()
    uppercase_count = sum(1 for char in text if char.isupper())
    print(f"Total number of uppercase characters in {filename}: {uppercase_count}")

filename = 'ABC.txt'
count_uppercase_characters(filename)

