# Function to count and display the total number of words in a text file ABC.txt
def count_words_in_file(filename):
    with open(filename, 'r') as file:
        text = file.read()
    words = text.split()
    word_count = len(words)
    print(f"Total number of words in {filename}: {word_count}")

filename = 'ABC.txt'
count_words_in_file(filename)
