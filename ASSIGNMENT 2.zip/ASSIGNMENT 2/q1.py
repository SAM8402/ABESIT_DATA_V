# Function to read the content from a text file ABC.txt line by line and display the same on screen

def read_and_display_file(filename):
    with open(filename, 'r') as file:
        for line in file:
            print(line.strip())

filename = 'ABC.txt'
read_and_display_file(filename)

