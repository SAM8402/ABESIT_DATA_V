# Python program that opens a file and handles a FileNotFoundError exception if the file does not exist


filename = 'non_existent_file.txt'

try:
    with open(filename, 'r') as file:
        content = file.read()
        print(content)
except FileNotFoundError:
    print(f"Error: The file '{filename}' does not exist.")

