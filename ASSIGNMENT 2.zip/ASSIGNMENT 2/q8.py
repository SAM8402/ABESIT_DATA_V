# Python program that prompts the user to input two numbers and raises a TypeError exception if the inputs are not numerical

try:
    num1 = input("Enter the first number: ")
    num2 = input("Enter the second number: ")

    if not (num1.replace('.', '', 1).isdigit() and num2.replace('.', '', 1).isdigit()):
        raise TypeError("Error: Both inputs must be numerical.")

    num1 = float(num1)
    num2 = float(num2)
    print(f"The sum of {num1} and {num2} is {num1 + num2}")

except TypeError as e:
    print(e)
