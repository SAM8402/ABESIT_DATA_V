# Python program that prompts the user to input an integer and raises a ValueError if the input is not a valid integer

try:
    number = int(input("Enter an integer: "))
    print(f"You entered: {number}")
except ValueError:
    print("Error: Invalid input. Please enter a valid integer.")

