# Function display_words() to read lines from a text file story.txt and display words that are less than 4 characters
def display_words(filename):
    with open(filename, 'r') as file:
        lines = file.readlines()
    
    for line in lines:
        words = line.split()
        short_words = [word for word in words if len(word) < 4]
        for word in short_words:
            print(word)

filename = 'story.txt'
display_words(filename)

